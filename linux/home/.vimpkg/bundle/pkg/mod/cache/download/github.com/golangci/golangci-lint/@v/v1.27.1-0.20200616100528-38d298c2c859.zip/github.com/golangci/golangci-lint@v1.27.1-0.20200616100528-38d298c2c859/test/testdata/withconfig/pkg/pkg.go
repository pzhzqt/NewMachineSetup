package pkg

func SomeTestFunc() {}
