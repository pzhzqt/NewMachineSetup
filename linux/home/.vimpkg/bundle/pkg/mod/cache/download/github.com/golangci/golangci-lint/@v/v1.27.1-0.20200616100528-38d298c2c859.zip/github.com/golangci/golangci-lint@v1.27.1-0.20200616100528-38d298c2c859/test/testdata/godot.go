//args: -Egodot
package testdata

// Godot checks top-level comments // ERROR "Top level comment should end in a period"
func Godot() {
	// nothing to do here
}
