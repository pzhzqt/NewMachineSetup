//args: -Etestpackage
package testdata // ERROR "package should be `testdata_test` instead of `testdata`"
