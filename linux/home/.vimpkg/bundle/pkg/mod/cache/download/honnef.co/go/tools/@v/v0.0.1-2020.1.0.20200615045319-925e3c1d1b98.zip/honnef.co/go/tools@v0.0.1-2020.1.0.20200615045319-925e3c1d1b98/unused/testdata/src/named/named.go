package pkg

type t1 struct{} // used
type T2 t1       // used
