// want package:"Phylum:Chordata,Echinodermata,Mollusca,platyhelminthes"

package bar

type Phylum int

const (
	Chordata Phylum = iota
	Echinodermata
	Mollusca
	platyhelminthes
)
